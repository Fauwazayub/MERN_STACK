let arr = [2,23,4,42];
// function printPretty(elem){
// //     console.log(': ',elem);
// // }
// function printArray(arr){
//     for(let i=0;i<arr.length;i++){
//         printPretty([arr]);
//     }

//     arr.forEach(printPretty);

// arr.forEach((elem,b,c) => {
//     console.log(': ',elem,b,c);
// });
//  printArray(arr);




// console.log('GEC Start');

// function printPretty(){
//     console.log('prettyStart');
//     let ans = 7+5;
//     console.log(ans);
//     console.log('prettyEnd');
// }
// setTimeout(printPretty,1000);
// console.log('GEC End');
console.log('Start');



console.log('end');