// function print(x='nothing is here'){
//     console.log(x);
// } 
// print('hello');
// print();
// function sum(a, b){
//     if(a && b){
//         console.log(a+b);
//     }else{
//         console.log(a);
//     }
    
// }
// sum(10);
//function decleratiom

// function print(){
//     console.log('--');
// }
// //function assignment (named)
// const s = function print(){
//     console.log('--');
// }
// //function assignment (anynomous)
// const b = function print(){
//     console.log('--');
// }
// //arrow function assignment 
// const j = () =>{
//     console.log('++');
// }
// print();
// s();
// b();
// j();
// const obj = new Object;
// obj[12] = 'twelve';
// obj[13] = 'thirteen';
// obj[14] = 'fourteen';
// console.log(obj);

const obj = {
    1: 'one',
    'FirstName': 'fauwaz',
    'LastName' : 'ayub',

}

