// var message = 'hello world'; 
// console.log(message);
// for( var i=0;i<5;i++){
//     console.log(i);
// }
//  console.log(i);
// const message = "hello";
// console.log(message);
 let arr = ['a','b','c','v'];
 let cpy = [...arr];
 console.log(arr, cpy);
 if(arr==cpy){
    console.log('1.yes');
 }
 else{
    console.log('1.no');
 }
 if(arr===cpy){
    console.log('2.yes');
 }
 else{
    console.log('2.no');
 }
// userAge = 23;
// console.log(typeof(userAge));
// let ar=["abcd"];
// console.log(ar);
// let str= '13';
// let age= 20;
// let ans = age + str-1;
// console.log(ans);
// let str = '12.12';
// let p = parseInt(str);
// let n = Number(str);
// console.log(p, n);
const str = 'khan';
const username = 'my name is:'; 
console.log(`${username} ${str}`);