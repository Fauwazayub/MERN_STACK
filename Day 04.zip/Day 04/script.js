// let a = new String("hello");
// let b = "hello";
// if(a==b){
//     console.log("yes");
// }
// else{
//     console.log("no");
// }
// const obj = {
//     "name": 'fauwaz',
//     "lastname": 'ayub'
// }
// // console.log(obj);
// obj.name = "sahil"; //key value assignment
// obj.age = 20;
// console.log(obj);
// let arr = [];
// const arr = [2,3,4];
// arr1.push(10);
// console.log(arr1);le
// console.log(typeof(arr1));
// arr1[2] = 4;
// console.log((array.isarray(obj)));
// console.log(array.isarray(arr1));/
// function checkifarray(x){
//      if(Array.isArray(x)==1){
//         console.log("yes");
//      }else{
//         console.log("no");
//      }
// }
// checkifarray([1,2,5,3]);
// for( let i of arr){
//     console.log[i];
// }
// for(let i in obj){
//     console.log(i);
// }
// console.dir(window.document);
// console.dir(window);
// console.log(window.document);
// console.log(window);
// console.log(innerHeight);
// console.log(innerWidth);
// const res = document.getElementsByTagName('h3');
// console.log(res);
// const res = document.queryselectorall('h3');
// const res = document.getElementsByTagName("div");
// res[0].innerHTML = " "
// console.log(res);
// const ne = document.createElement("h3");
// // console.log(ne);
// ne.innerText = "dynamic text";
// const firstdiv = document.getElementsByTagName('div');
// firstdiv[0].appendChild(ne);
// console.log(ne);
// const res = document.querySelector('div');
// const c =  document.querySelector('p');
// res.removeChild(c);
function getInfo(e){
    const d = document.querySelector("div");
    // const e = document.createElement('p');
    // e.innerText = "fauwaz ayub";
    // d.prepend('ghghg');
console.log(e);

e.target.style.backgroundColor = 'red';
e.target.style.color = 'white';
}
