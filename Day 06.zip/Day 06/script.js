// console.log('start');
// setTimeout()
// console.log('end');
// setTimeout(()=>{
//     console.log('timeout 1...')},20000);
// console.log('start');
// setTimeout(()=>{
//     console.log('timeout 2...')},20000);
// console.log('intermediate');
// console.log('end');


// function createOrder(x, fn){
//     console.log(x);
//     setTimeout(()=>{fn('12345')},1000)
// } 
// function orderID(orderID){
//     console.log(orderID);
// }
// createOrder('soap');




// const pr = new Promise((resolve,reject)=>{ setTimeout(()=>{reject("some items are out of stock");},5000);   
// });
// setTimeout(() => {
//     console.log('first timeout...')},0);
//   console.log(pr);
// pr.then((res)=>{
//   console.log(res);
// }).catch((err)=>{
//     console.log(err);
// });
// setTimeout(function abc() {
//     console.log("i am one");
// }, 0);
// const pr = new promise((res,rej) => {
//     setTimeout(() => {
        
//     }, timeout);
// }, 0);
// console.log('hello');
//  const arr = [1,2,42,4];
//  const arr2 = [13,23,42,41];
//   const ans3 = arr.map(=> {
//     console.log(a);
//     return a*2;
//  }); 
//      console.log(ans3);/


// const arr = [
//     'Kanpur india',
//     'Delhi India',
//     'Lucknow India',
//     'Kolkata',
//     'Pune',
//     'china',
//     'UAE',
//     'India'
// ];
// let newArr = arr.filter((s) =>{
//        if(s.includes('i') || s.includes('I')){
//         return true;
//        }
//         else false;
// });
// console.log(newArr);


// const array = arr.filter((s)=>{
//     s.toLowerCase(),includes('india')});
//     if(arr.includes('india')){
//         return true;
//     }
//     else{
//         return false;
//     }
// console.log(array);
// let div = document.querySelector("div");
// let newBox = document.getElementById = "box";
// div.innerText = "hello";
// let body = document.querySelector("div");
// let heading = 
let NewBtn = document.createElement("button");
NewBtn.innerText = "click Me";
NewBtn.style.color = "white";
NewBtn.style.backgroundColor = "red";
document.querySelector("body").prepend(NewBtn);